
public class Small_Object {
	int x;
	int y;
	EZImage picture1;
	EZImage picture2;
	EZImage picture3;
	EZImage picture4;
	EZImage picture5;
	
	Small_Object() {
		picture1 = EZ.addImage("first_aid.png", 200, 500);
		picture2 = EZ.addImage("skrillex.png", 900, 100);
		picture3 = EZ.addImage("dog.png", 800, 400);
		picture4 = EZ.addImage("cat.png", 500, 700);
		picture5 = EZ.addImage("woman.png", 400, 200);
		
			}

	void delete1() {
		picture1.translateTo(10000, 10000);
	}
	void delete2() {
		picture2.translateTo(10000, 10000);
	}
	void delete3() {
		picture3.translateTo(10000, 10000);
	}
	void delete4() {
		picture4.translateTo(10000, 10000);
	}
	void delete5() {
		picture5.translateTo(10000, 10000);
	}

}
