import java.util.Random;

public class Zombie {
	int x;
	int y;
	EZImage picture;
	int speed;
	
	Zombie() {
		Random randomgenerator;
		randomgenerator = new Random();
		x = randomgenerator.nextInt(1024);
		y = randomgenerator.nextInt(768);
		picture = EZ.addImage("moving_zombie.png", x, y);
		picture.scaleTo(0.50);
		speed = randomgenerator.nextInt(10) + 7;
	}
	void sideToside() {
		x = picture.getXCenter() + speed;
		y = picture.getYCenter();
		picture.translateTo(picture.getXCenter() + speed, picture.getYCenter());
		if (picture.getXCenter() > 1000) {
			speed = -speed;
		}
		if (picture.getXCenter() < 0) {
			speed = -speed;
		}
	}
}
