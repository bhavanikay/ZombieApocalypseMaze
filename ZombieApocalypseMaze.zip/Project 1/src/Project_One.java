import java.awt.Color;

public class Project_One {
	
	public static void main(String[] args) {
		EZ.initialize(1000, 800);
		EZImage game_over = EZ.addImage("game_over.jpg", 500, 400);
		game_over.hide();
		EZImage background = EZ.addImage("zombie.png", 500, 400);
		EZText text;		
		
		EZSound crash = EZ.addSound("crashing.wav");
		EZSound chime = EZ.addSound("chime.wav");
		EZSound growl = EZ.addSound("zombie_growl.wav");
		Car car = new Car();
		
		//array to hold 5 buildings
		int large = 5;
		Buildings[] buildings = new Buildings[large];
		for (int i = 0; i < large; i++) {
			buildings[i] = new Buildings();	
		}
		//array to hold 5 small objects 
		int small = 5;
		Small_Object[] small_objects = new Small_Object[small];
		for (int i = 0; i < small; i++) {
			small_objects[i] = new Small_Object();
		}
		//array to hold 5 moving zombies
		int zombie = 3;
		Zombie[] moving_zombie = new Zombie[zombie];
		for (int i = 0; i < zombie; i++) {
			moving_zombie[i] = new Zombie();
		}
		long time = System.currentTimeMillis();
		int health = 100;
		Color b = new Color(200,0,0);
		text = EZ.addText(500, 50, "Food: " + health, b, 50);
		
		while (health > 0) {
			car.move();
			for (int i = 0; i < 3; i++) {
				moving_zombie[i].sideToside();
			}
			for (int i = 0; i < large; i++ ) {
				if (buildings[i].picture.isPointInElement(car.x, car.y)) {
					crash.play();
					game_over.pullToFront();
					game_over.show();
				}
				
			} 
			//adding points for hitting collectibles
			for (int i = 0; i < small; i++) {
				if (small_objects[i].picture1.isPointInElement(car.x,car.y)) {
					chime.play();
					health += 10;
					small_objects[i].delete1();
				}
				if (small_objects[i].picture2.isPointInElement(car.x,car.y)) {
					chime.play();
					health += 10;
					small_objects[i].delete2();
				}
				if (small_objects[i].picture3.isPointInElement(car.x,car.y)) {
					chime.play();
					health += 10;
					small_objects[i].delete3();
				}
				if (small_objects[i].picture4.isPointInElement(car.x,car.y)) {
					chime.play();
					health += 10;
					small_objects[i].delete4();
				}
				if (small_objects[i].picture5.isPointInElement(car.x,car.y)) {
					chime.play();
					health += 10;
					small_objects[i].delete5();
				}
			}
			for (int i = 0; i < zombie; i++) {
				if (moving_zombie[i].picture.isPointInElement(car.x,car.y)
						&& System.currentTimeMillis() - time > 100) {
					growl.play();
					health -= 10;
					time -= 10;
					time = System.currentTimeMillis();
				}
				
			}
			if (System.currentTimeMillis() - time > 300) {
				health--;
				time = System.currentTimeMillis();
			}
			text.setMsg("Health: " + health);
			EZ.refreshScreen();
		}
		game_over.pullToFront();
		game_over.show();
		EZ.refreshScreen();		
	}	
}