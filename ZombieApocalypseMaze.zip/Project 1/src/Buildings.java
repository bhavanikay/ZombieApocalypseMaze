import java.util.Random;

public class Buildings {
	int x;
	int y;
	EZImage picture;
	
	Buildings() {
		Random randomgenerator;
		randomgenerator = new Random();
		x = randomgenerator.nextInt(1024);
		y = randomgenerator.nextInt(768);
		picture = EZ.addImage("building1.png", x, y);
		picture.scaleTo(0.70);
	}
	void teleport() {
		picture.translateTo(10000, 10000);
	}
}
