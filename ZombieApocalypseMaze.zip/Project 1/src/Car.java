public class Car {
	int x;
	int y;
	EZImage picture;
	
	Car(){
		x = 100;
		y = 50;
		picture = EZ.addImage("truck.png", x, y);
	}
	void move() {
		if (EZInteraction.isKeyDown("w")) {
			y = y - 6;
		}
		if (EZInteraction.isKeyDown("s")) {
			y = y + 6;
		}
		if (EZInteraction.isKeyDown("a")) {
			x = x - 6;
		}
		if (EZInteraction.isKeyDown("d")) {
			x = x + 6;
		}
		picture.translateTo(x, y);
	}
}
